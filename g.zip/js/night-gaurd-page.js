$(document).ready(function() {
	$(".read-more-about-night-gaurd-isp > a").click(function(event) {
		event.preventDefault();
		$(".bg-extra-night-gaurd-services-info-isp").slideToggle(700);
	});
});