$(document).ready(function() {
	$(".read-more-about-crown-and-bridges-isp > a").click(function(event) {
		event.preventDefault();
		$(".bg-extra-crown-and-bridges-services-info-isp").slideToggle(700);
	});
});