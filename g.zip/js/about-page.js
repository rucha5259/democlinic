$(document).ready(function() {
	$('.info-tab-listing-ap > li > a').click(function(event){
		event.preventDefault(); // stop browser to take action for clicked anchor
		// get displaying tab content jQuery selector
		var active_tab_selector = $('.info-tab-listing-ap > li.active > a').attr('href');
		// find actived navigation and remove 'active' css
		var actived_nav = $('.info-tab-listing-ap > li.active');
		actived_nav.removeClass('active');
		// add 'active' css into clicked navigation
		$(this).parents('li').addClass('active');
		// hide displaying tab content
		$(active_tab_selector).removeClass('active');
		$(active_tab_selector).addClass('hides');
		// show target tab content
		var target_tab_selector = $(this).attr('href');
		$(target_tab_selector).removeClass('hides');
		$(target_tab_selector).addClass('active');
	});
	// About Slick Slider JS
	$(".slick-slider-pati-testi-ap").slick({
		dots: true,
		infinite: false,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		responsive: [
			{
				breakpoint: 1199,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
			},
			{
				breakpoint: 992,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 575,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	});
});