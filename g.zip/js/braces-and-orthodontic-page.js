$(document).ready(function() {
	$(".read-more-about-braces-orthodontic-isp > a").click(function(event) {
		event.preventDefault();
		$(".bg-extra-braces-orthodontic-services-info-isp").slideToggle(700);
	});
});