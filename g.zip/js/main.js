$(document).ready(function() {
	// Smooth Scroll JS
	var $window = $(window)
  document.onmousewheel = function () {
    customScroll()
  }
  if (document.addEventListener) {
    document.addEventListener('DOMMouseScroll', customScroll, false)
  }
  function customScroll(event) {
    var delta = 0
    if (!event) {
        event = window.event;
    }
    if (event.wheelDelta) {
        delta = event.wheelDelta / 120
    } else if (event.detail) {
        delta = -event.detail / 3
    }
    if (delta) {
        var scrollTop = $window.scrollTop()
        var finScroll = scrollTop - parseInt(delta * 50) * 3
        TweenMax.to($window, 1, {
            scrollTo: {y: finScroll, autoKill: true},
            ease: Power1.easeOut,
            autoKill: true,
            overwrite: 5
        })
    }
    if (event.preventDefault) {
        event.preventDefault()
    }
    event.returnValue = false
  }
	// OnScroll Navbar Fixed
	$(window).scroll(function(){
	  if ($(window).scrollTop() >= 50) {
	    $(".bg-navbar-menu-one-desktop").addClass('active');
	   } else {
	    $(".bg-navbar-menu-one-desktop").removeClass('active');
	   }
	});
	// On Scroll Up Navbar Menu JS
	var lastScrollTop = 0, 
	delta = 5;
	$(window).scroll(function(event){
 		var st = $(this).scrollTop();
 		if(Math.abs(lastScrollTop - st) <= delta)
    	return;
 		if (st > lastScrollTop){
     	// Down Scroll JS
   		$(".bg-navbar-menu-two-desktop").removeClass("active");
 		} else {
    	// Up Scroll JS
    	$(".bg-navbar-menu-two-desktop").addClass("active");
			}
 		lastScrollTop = st;
	});
	// Detect when user scrolls to top JS
	var $win = $(window);
	$win.scroll(function () {
	 if ($win.scrollTop() == 0)
	     $(".bg-navbar-menu-two-desktop").removeClass("active");
	 else if ($win.height() + $win.scrollTop() == $(document).height()) {
	     $(".bg-navbar-menu-two-desktop").addClass("active");
	 }
	});
	// Navigationbar Menu JS
	$(".burger-menu").click(function() {
		$(this).toggleClass("active");
		$(".bg-blur").toggleClass("active");
		$("body").toggleClass("active");
		$(".bg-navbar-menu-two-desktop").toggleClass("remove-bg");
		$(".fixed-sidebar").toggleClass("active");
		$(".menu-listing").toggleClass("active");
		$(".header-call-info").toggleClass("active");
    $(".display-rotate-email").toggleClass("active");
    $(".display-center-social-media-icons").toggleClass("active");
	});
  // Fixed Bottom Helping Hands JS
  $(".fixed-bottom-contact-info > a").click(function(event) {
    event.preventDefault();
    $(".helping-hands-listing").toggleClass("active");
  });
  $(".fixed-bottom-contact-info > a").click(function(event) {
    event.preventDefault();
    $(this).children().toggleClass("active");
  });
	// Scroll To Top JS
  var webPageoffset = 200;
  var duration = 500;
  $(window).scroll(function() {
    if($(this).scrollTop() > webPageoffset) {
      $(".scroll-to-top").addClass("active");
    } else {
      $(".scroll-to-top").removeClass("active");
    }
  });
  $(".scroll-to-top").click(function() {
    $('html,body').animate({scrollTop: 0},2000);
  });
});
// Disabled All "Ctrl" and "Ctrl + shift" Key JS 
document.onkeydown = function (e) {
  if (event.keyCode == 123) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'E'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'H'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'A'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'F'.charCodeAt(0)) {
    return false;
  }
  if (e.ctrlKey && e.keyCode == 'E'.charCodeAt(0)) {
    return false;
  }
}
// Disabled Right Click JS
// document.addEventListener('contextmenu', event => event.preventDefault());