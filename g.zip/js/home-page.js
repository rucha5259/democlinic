$(document).ready(function() {
  // Detect When User Reach Particular Section
  $(".vertical-menu-listing-home").onePageNav({
    currentClass: 'active',
    changeHash: false,
    scrollSpeed: 1400,
    scrollThreshold: 0.10,
    filter: '',
    easing: 'swing'
  });
  // Smooth Animation On Click of Vertical Menu JS
  $(".vertical-menu-listing-home > li > a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 1400);
    }
  });
  // Vertical Menu JS
  $(".vertical-menu-listing-home > li > a").click(function() {
    $(".vertical-menu-listing-home > li > a").parent().removeClass("active");
    $(this).parent().addClass("active");
  });
  // Counter JS
  var counted = 0;
  $(window).scroll(function() {
    var oTop = $('#counter').offset().top - window.innerHeight;
    if (counted == 0 && $(window).scrollTop() > oTop) {
      $('.count').each(function() {
        var $this = $(this),
          countTo = $this.attr('data-count');
        $({
          countNum: $this.text()
        }).animate({
            countNum: countTo
          },
          {
            duration: 4000,
            easing: 'swing',
            step: function() {
              $this.text(Math.floor(this.countNum));
            },
            complete: function() {
              $this.text(this.countNum);
            }
          });
      });
      counted = 1;
    }
  });
	// At a Glance Section JS
  var ataGlanceSecHomeOffset = $(".bg-counter-home").offset().top - 500;
  $(window).scroll(function() {
    var windScllTop = $(window).scrollTop();
    if (ataGlanceSecHomeOffset < windScllTop) {
      $(".counter-square-shape-home").addClass("active");
    } else {
      $(".counter-square-shape-home").removeClass("active");
    }
  });
  // Contact Section JS
  var contactSecHomeOffset = $(".bg-contact-address-home").offset().top - 500;
  $(window).scroll(function() {
    var windScllTop = $(window).scrollTop();
    if (contactSecHomeOffset < windScllTop) {
      $(".contact-map-shape-home").addClass("active");
    } else {
      $(".contact-map-shape-home").removeClass("active");
    }
  });
  // On Scroll "Success Section" Rellax Animation JS
  var counterCirHomeImg = new Rellax('.counter-circle-shape-img-home', {
    speed: 7,
    center: true,
    wrapper: null,
    round: true,
    vertical: true,
    horizontal: false
  });
  // On Scroll "Contact Section" Rellax Animation JS
  var contactSecCirHomeImg = new Rellax('.contact-map-home > a > iframe', {
    speed: 4,
    center: true,
    wrapper: null,
    round: true,
    vertical: true,
    horizontal: false
  });
  // On Scroll "Get Direction Button" Rellax Animation JS
  var getDirBtnHomeImg = new Rellax('.btn-get-direction-home', {
    speed: 4,
    center: true,
    wrapper: null,
    round: true,
    vertical: true,
    horizontal: false
  });
  // AOS Animation JS
  AOS.init({
    easing: 'ease-in-out-sine'
  });
});
$(window).on("load", function() {
  // Banner Slick SLider JS
  $(".banner-slick-slider-home").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    autoplay: true,
    autoplaySpeed: 2000,
    cssEase: 'ease-in-out',
    asNavFor: '.banner-slick-slider-heading-home'
  });
  $(".banner-slick-slider-heading-home").slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.banner-slick-slider-home',
    arrows: false,
    dots: false,
    centerMode: false,
    focusOnSelect: true,
    responsive: [
			{
				breakpoint: 1199,
				settings: {
					slidesToShow: 2,
          slidesToScroll: 1
				}
			},
			{
				breakpoint: 992,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 575,
				settings: {
					slidesToShow: 1,
          slidesToScroll: 1
				}
			}
		]
  });
});