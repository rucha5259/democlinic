$(document).ready(function() {
	$(".read-more-about-dental-fillings-isp > a").click(function(event) {
		event.preventDefault();
		$(".bg-extra-dental-fillings-services-info-isp").slideToggle(700);
	});
});