<meta name="description" content="The Dental Clinic is highly equipped with latest equipment for single sitting RCT, Complicated Implant surgeries, Digital patient record keeping and Digital intro oral x rays. The Clinic also has ample parking space, waiting area, welcoming reception and in-clinical waiting Area. We, at Dr. Gandhi Dental Clinic ensures 100% sterilization, with B-Class autoclave to Ensure patient safety." />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />
<meta name="author" content="Hi-Lab Solution" />
<script>(function(w, d) { w.CollectId = "5fcca21f09ea3c02540019a9"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.async=true; s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-33659855-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-33659855-1');
</script>